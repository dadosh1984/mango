<div align="center">

# 🥭 ** MangoWC-Dots - (2026) ** 🥭

### Minimal & Extensible Wayland Compositor Setup with Noctalia Shell

<p align="center">
  <img src="https://raw.githubusercontent.com/LinuxBeginnings/Hyprland-Dots/main/assets/latte.png" width="400" />
</p>

[![LinuxBeginnings](https://img.shields.io/badge/LinuxBeginnings-Community-blue?style=for-the-badge)](https://github.com/LinuxBeginnings)
[![License: GPL v3](https://img.shields.io/badge/License-GPLv3-green.svg?style=for-the-badge)](https://www.gnu.org/licenses/gpl-3.0)
<a href="https://discord.gg/RZJgC7KAKm"><img src="https://img.shields.io/discord/1151869464405606400?style=for-the-badge&logo=discord&color=cba6f7&label=Discord" /></a>

<br/>

<div align="center">
  <a href="#-overview"><kbd> <br> Overview <br> </kbd></a>&ensp;&ensp;
  <a href="#-features"><kbd> <br> Features <br> </kbd></a>&ensp;&ensp;
  <a href="#-installation"><kbd> <br> Installation <br> </kbd></a>&ensp;&ensp;
  <a href="#-configuration-colocation"><kbd> <br> Configuration <br> </kbd></a>&ensp;&ensp;
  <a href="#-greeter-integration"><kbd> <br> Greeter <br> </kbd></a>
</div>

<br/>
</div>

---

## 📖 Overview

**MangoWC - (2026)** is an extensible, multi-distribution installer engineered for a minimal, lightning-fast Wayland desktop environment pairing the **Mango** Wayland compositor with **Noctalia Shell**, styled with **Kitty** terminal and **Fastfetch**.

Unlike bloated scripts that install dozens of non-essential applications, this installer focuses strictly on core desktop components, Wayland essentials, and streamlined configuration.

---

## ✨ Features

- **Lean Core Desktop:** Zero bloat. Installs only `mangowc`, `noctalia`, `quickshell`, `kitty`, file management (`thunar`, `yazi`), terminal productivity utilities (`eza`, `htop`, `btop`, `zoxide`, `cava`), and essential Wayland display & recording utilities (`wlr-randr`, `wl-mirror`, `grim`, `slurp`, `gpu-screen-recorder`, `xdg-desktop-portal-wlr`). No NVIDIA proprietary builds, no OBS, and no heavy unnecessary apps.
- **Quickshell Ecosystem Ready:** Pre-configures the Quickshell repository/dependencies (`qt6-qtdeclarative`, `qt6-qtwayland`, `qt6-qt5compat`, `qt6-qtsvg`, `qt6-qtmultimedia`, `qt6-qtimageformats`, `socat`, `jq`) so you can run custom Quickshell bars, overviews, and widgets out of the box.
- **Virtual Machine Aware:** Automatically detects hypervisors (KVM, QEMU, Proxmox, VMware, VirtualBox) across all distros, installs `qemu-guest-agent`, enables the guest service, configures software cursor fallbacks (`WLR_NO_HARDWARE_CURSORS=1`), and masks missing hardware services to prevent timeouts.
- **Pure Kitty Integration:** All keybindings and configs are unified around `kitty` — foot and foot-client configs are eliminated.
- **Config Colocation:** Keeps all Mango configurations and related application configurations consolidated under `~/.config/mangowc/` (including `kitty.conf`), maintaining clean compatibility via a `~/.config/mango -> mangowc` symlink.
- **Safe Automatic Backups:** Automatically backs up modified directories prior to installation with timestamps (e.g. `~/.config/fastfetch` ➔ `~/.config/fastfetch-mangowc-<timestamp>`).
- **Noctalia Greeter & greetd:** Optional interactive or command-line installation and rollback management for `noctalia-greeter` on `greetd`.
- **Wallpaper-Bank Download Prompt:** Features the LinuxBeginnings interactive prompt for downloading wallpapers, complete with AI-generated content disclosures and download size warnings.
- **Modular Multi-Distro Engine:** Shared libraries under `lib/` (`common.sh`, `detect.sh`, `greeter.sh`, `wallpapers.sh`) with distro-isolated packages and setups under `distros/<distro>/` (Gentoo, Arch, Fedora, Debian, Ubuntu).
- **Debugging & Logging:** Detailed logging to `Install-Logs/install-<timestamp>.log` with an optional `--debug` flag for verbose execution.

---

## 🚀 Installation

Clone this repository and run the installer:

```bash
git clone https://github.com/LinuxBeginnings/mangowc.git
cd mangowc
chmod +x install.sh
./install.sh
```

### CLI Options

The installer supports several non-interactive and debugging flags:

| Flag | Description |
| --- | --- |
| `-d`, `--debug` | Enable verbose shell tracing (`set -x`) and detailed debug logs |
| `-u`, `--uninstall` | Completely uninstall MangoWC, Noctalia, and restore previous configuration |
| `--install-greeter` | Non-interactively configure `greetd` with `noctalia-greeter` |
| `--remove-greeter` | Restore previous display manager / `greetd` configuration |
| `--skip-greeter` | Skip login manager / greeter configuration |
| `--no-wallpapers` | Bypass wallpaper bank download prompt |
| `--update-noctalia` | Check for Noctalia & Greeter updates and prompt to upgrade |
| `--deps` | Install missing packages only, without redeploying configs |
| `--dry-run` | Report what would be installed or changed, then exit without touching the system |
| `-h`, `--help` | Display usage options |

---

## 📁 Directory Architecture

```
mangowc/
├── install.sh                  # Main orchestrator
├── README.md                   # Documentation
├── tests/                      # Offline checks (no root, no system changes)
│   └── upgrade-rehearsal.sh    # Rehearses the v0.1.x .conf -> TOML upgrade
├── lib/                        # Multi-distro common libraries
│   ├── common.sh               # Colors, logging, sudo keepalive, backup helpers
│   ├── detect.sh               # /etc/os-release parsing and VM/distro matcher
│   ├── greeter.sh              # greetd + noctalia-greeter installation & rollback
│   ├── update.sh               # Noctalia & greeter update check (--update-noctalia)
│   └── wallpapers.sh           # Wallpaper-Bank cloning with AI warning
├── distros/                    # Distribution-specific modules
│   ├── fedora/
│   │   ├── packages.sh         # Lean package lists (mangowm, noctalia, kitty, etc.)
│   │   └── setup.sh            # DNF parallel downloads, COPR & Terra/RPM Fusion repos
│   ├── arch/                   # Arch Linux packages (yay/paru AUR support)
│   ├── gentoo/                 # Gentoo Linux (emerge binary/source + GURU + source mango 0.18.4)
│   ├── ubuntu/                 # Ubuntu 26.04+ (ButterRepo + APT packages)
│   └── debian/                 # Modular stub for Debian
└── configs/
    ├── btop/                   # Target: ~/.config/btop/
    │   └── btop.conf
    ├── fastfetch/              # Target: ~/.config/fastfetch/
    │   └── config.jsonc
    ├── ghostty/                # Target: ~/.config/ghostty/
    │   └── config
    ├── greetd/                 # Target: /etc/greetd/
    │   └── config.toml
    ├── noctalia/               # Target: ~/.config/noctalia/
    │   └── settings.toml       # Shell settings (single default bar)
    ├── kitty/                  # Target: ~/.config/kitty/ (Noctalia-themeable)
    │   ├── current-theme.conf
    │   └── kitty.conf
    ├── yazi/                   # Target: ~/.config/yazi/ (Noctalia flavor)
    │   ├── flavors/
    │   └── theme.toml
    └── mangowc/                # Target: ~/.config/mangowc/
        ├── autostart.sh        # Portal & Noctalia startup
        ├── bind.toml           # Mango keybindings
        ├── config.toml         # Mango compositor config (scroller proportions)
        ├── env.toml            # Dynamic Wayland environment & MANGO_DEFAULT_LAYOUT
        ├── monitor.toml        # Display rules (Virtual-1 pinned to 1920x1080@60)
        ├── noctalia.toml       # Theme colors
        ├── rule.toml           # Window rules (floating-kitty, etc.)
        ├── tag.toml            # Workspace tag layout
        └── bin/                # Helper scripts
            ├── reload.sh       # Mango & Noctalia reloader
            ├── screenshot.sh   # Grim + Slurp screenshot tool
            ├── set-icons       # Tela icon switcher
            └── toggle-outer-gaps.sh
```

---

## 🗂 Configuration & Theming Integration

- **Standard XDG Locations**: App configs (`kitty`, `ghostty`, `btop`, `yazi`, `fastfetch`) are deployed directly to `~/.config/<app>` so Noctalia Shell's theme engine can seamlessly generate and apply color schemes (e.g. `~/.config/kitty/current-theme.conf`, `~/.config/yazi/theme.toml`).
- **Mango Compositor**: Configured under `~/.config/mangowc` with an automatic symlink `~/.config/mango -> mangowc`.
- **Default Layout**: Controlled via `"MANGO_DEFAULT_LAYOUT" = "..."` in `~/.config/mangowc/env.toml`. Reloading via `Super + Alt + R` or `~/.config/mangowc/bin/reload.sh` synchronizes this layout across all tags in `tag.toml`.

### Upgrading from v0.1.x

v0.2.0 moves the compositor config to TOML for Mango 0.18.4. Re-running `./install.sh` deploys the new `*.toml` files and deletes the stale `config/bind/env/monitor/tag/rule/noctalia.conf` files, because mango loads `config.conf` in preference to `config.toml`. Your previous `~/.config/mangowc` is moved to `~/.config/mangowc-backup-<timestamp>` first, but hand edits from the old `.conf` files are **not** carried over — re-apply them in the matching `.toml` file, using the 0.18 names (`exec_once`, `window_rule`, `tag_rule`, `monitor_rule`, and snake_case colour keys such as `focus_color`).

---

## 🔐 Greeter Integration

When `noctalia-greeter` is selected, `greetd` is configured to launch:
```toml
[default_session]
command = "noctalia-greeter-session -- --session mango"
user = "greeter"
```
Avatars and themes will automatically reflect the user's settings when AccountsService is active. To revert back to your previous display manager configuration, run:
```bash
./install.sh --remove-greeter
```

---

<div align="center">
  <sub>Maintained by the <strong>LinuxBeginnings</strong> project.</sub>
</div>
